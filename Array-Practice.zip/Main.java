import java.util.*;
class Main {
  public static void main(String[] args) 
  {
Scanner scan = new Scanner(System.in);

//Greetings
System.out.println("\nWhy Hello There! ( •ᴗ•)/ \nWELCOME TO THE CELL PHONE STORE! \n \nFeel Free to Observe The Cell Phone Options We Offer Below!");

//Creation of Object 1
    CellPhone cp1 = new CellPhone("Nokia", "G300", "Verizon", 2021, 4, true);
    System.out.println(cp1);

//Creation of Object 2
    CellPhone cp2 = new CellPhone("Motorola", "Razr", "AT&T", 2022, 12, true);
    System.out.println(cp2);

//Creation of Default Constructor Object
    CellPhone cp3 = new CellPhone();
    System.out.println(cp3);

// FAQ PAGE & (Other Method 1: .equals Method)
    System.out.println("\n \n Below Are Some FAQ's Regarding Our Phones: \n ------------------------------------------ \n Are Cellphone 1 and Cellphone 2 the same Brand? \n(Using the .equals Method)" + "\n\n " + cp2.equals(cp3));


// "compareTo Other Method"
    System.out.println("\n\n Are Cellphone 1 & Cellphone 3 the same brand? \n(Using the .compareTo Method)" + "\n\n " + cp1.compareTo(cp3));

/*
// "Other Method 2"
    System.out.println("\n Do Cellphone 1 & Cellphone 2 support 5G? " + "\n " + cp1.equalFG(cp1,cp2));
*/

/*
//Cell Phone Count Display
    System.out.println("\n How Many Cell Phones Do You Currently Offer? " + CellPhone.getCount());
*/
  
    //Creation of the 2D Array of the CellPhones
    System.out.println("------------------------------------------");
    System.out.println("\n\n- Creation of the 2D CellPhone array -");
    System.out.print("Enter the number of rows: ");
    int rows = scan.nextInt();
    System.out.print("Enter the number of columns: ");
    int columns = scan.nextInt();
    OrganizeCellPhone phones = new OrganizeCellPhone(rows, columns);
    System.out.println("\nOriginal 2D Array:");
    System.out.println(phones.toString());
    System.out.println();

    // array modifications
    System.out.println("- Modifications of phones in the array -");
    int choice = 0;
    while (choice != 2) {
      System.out.println("Would you like to modify an object? Enter [1] for yes and [2] for no.");
      choice = scan.nextInt();

      if (choice == 1) {
        System.out.print("Enter the row index: ");
        int row = scan.nextInt();
        System.out.print("Enter the column index: ");
        int col = scan.nextInt();
        System.out.print("Enter the new Phone type: ");
        scan.nextLine();
        
        String brandName = scan.nextLine();
        phones.getCellPhones()[row][col].setBrand(brandName);
        System.out.println("\n2D Array after modification:");
        System.out.println(phones.toString());
      } else if (choice == 2) {
        break;
      }
    }
    System.out.println();

    // Using sortRow
    System.out.println("------------------------------------------");
    System.out.println("");
    System.out.println("- Using sortRow method to sort the given row in an increasing order -\n");
    System.out.println("After calling sortRow(1)");
    phones.sortRow(1);
    System.out.println(phones.toString());
    System.out.println();

    // Using sortCol
    System.out.println("- Using sortCol method to sort the given column in an increasing order -\n");
    System.out.println("After calling sortCol(0)");
    phones.sortCol(0);
    System.out.println(phones.toString());
    System.out.println();

    // Using sortRowMajor
    System.out.println("- Using sortRowMajor method to sort the 2D Array in row major order -\n");
    System.out.println("2D Array after sorting in row major order:");
    phones.sortRowMajor();
    System.out.println(phones.toString());
    System.out.println();

    // using sortColMajor
    System.out.println("- Using sortColMajor method to sort the 2D Array in column major order -\n");
    System.out.println("2D Array after sorting in column major order:");
    phones.sortColMajor();
    System.out.println(phones.toString());
  }
}



/*
//CELL PHONE PUNS...mainly to lighten the mood and user experience
System.out.println("\n What is a tiny cell phone called? \n A Microphone.");

System.out.println("\n What does a lobster say when it picks up the phone? \n Shello.");

System.out.println("\n How does a pirate communicate? \n With his aye phone.");

System.out.println("\n How did Sam win the talent show? \n Sam-sung.");

System.out.println("\n What happens when your throw your phone in a lake? \n It will start Syncing.");

System.out.println("\n \n \n \n --- \n Are you done looking around already, and want to exit? \n [Type: y/n]");
*/

/*
//Store Exit Program
String input = scan.nextLine();

if (input.equals("y"))
{
  System.out.println("Bye-Bye! ( •ᴗ•)/");
}
else
{
  System.out.println("Take your time, we're open 24 hours!");  
}


  }
}
*/