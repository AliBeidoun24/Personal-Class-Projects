public class OrganizeCellPhone {
  // Instance data for a 2D array containing objects from the CellPhone class
  private CellPhone[][] cellPhones;

  // Constructor with parameters that includes row and col values.
  // Instantiate the 2D array in this parameterized constructor populated with default constructor from the CellPhone class.
  public OrganizeCellPhone(int row, int cols) {
    cellPhones = new CellPhone[row][cols];
    for (int i = 0; i < row; i++) {
      for (int j = 0; j < cols; j++) {
        cellPhones[i][j] = new CellPhone();
      }
    }
  }

   // Default constructor
   public OrganizeCellPhone() {
      this(5, 5);
   }

    public CellPhone[][] getCellPhones() {
    return cellPhones;
  }

    // sortRow Method
  public CellPhone[][] sortRow(int row) {
    for (int i = 0; i < cellPhones[row].length - 1; i++) {
      int min = i;
      for (int j = i + 1; j < cellPhones[row].length; j++) {
        if (cellPhones[row][j].compareTo(cellPhones[row][min]) < 0) {
          min = j;
        }
      }
      CellPhone temp = cellPhones[row][min];
      cellPhones[row][min] = cellPhones[row][i];
      cellPhones[row][i] = temp;
    }
    return cellPhones;
  }

  // sortCol Method
  public CellPhone[][] sortCol(int col) {
    for (int i = 0; i < cellPhones.length - 1; i++) {
      int min = i;
      for (int j = i + 1; j < cellPhones.length; j++) {
        if (cellPhones[j][col].compareTo(cellPhones[min][col]) < 0) {
          min = j;
        }
      }
      CellPhone temp = cellPhones[min][col];
      cellPhones[min][col] = cellPhones[i][col];
      cellPhones[i][col] = temp;
    }
    return cellPhones;
  }

  // sortRowMajor Method
  public CellPhone[][] sortRowMajor() {
    for (int i = 0; i < cellPhones.length; i++) {
      sortRow(i);
    }
    return cellPhones;
  }

  // sortColMajor
  public CellPhone[][] sortColMajor() {
    for (int i = 0; i < cellPhones[0].length; i++) {
      sortCol(i);
    }
    return cellPhones;
  }


  // toString Method
  public String toString() {
    String result = "";
    for (int i = 0; i < cellPhones.length; i++) {
      for (int j = 0; j < cellPhones[i].length; j++) {
        result += cellPhones[i][j].toString() + "\t";
      }
      result += "\n";
    }
    return result;
  }

}