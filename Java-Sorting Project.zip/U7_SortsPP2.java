import java.io.*;
import static java.lang.System.*;
import java.util.Scanner;
import java.lang.Math;
import java.util.ArrayList;
import java.util.Arrays;

public class U7_SortsPP2 {

       public static void SelectionSort(ArrayList<Integer> selectionSortArray) {
        for (int i = 0; i < selectionSortArray.size() - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < selectionSortArray.size(); j++) {
                if (selectionSortArray.get(j) < selectionSortArray.get(minIndex)) {
                    minIndex = j;
                }
            }
            System.out.println(selectionSortArray);
            int temp = selectionSortArray.get(i);
            selectionSortArray.set(i, selectionSortArray.get(minIndex));
            selectionSortArray.set(minIndex, temp);
        }
    }

    public static void SelectionSort2(ArrayList<Integer> selectionSortArray2) {
        for (int i = 0; i < selectionSortArray2.size() - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < selectionSortArray2.size(); j++) {
                if (selectionSortArray2.get(j) > selectionSortArray2.get(minIndex)) {
                    minIndex = j;
                }
            }
            System.out.println(selectionSortArray2);
            int temp = selectionSortArray2.get(i);
            selectionSortArray2.set(i, selectionSortArray2.get(minIndex));
            selectionSortArray2.set(minIndex, temp);
        }
    }

    public static void WordSelectionSort(ArrayList<String> elements) {
        for (int i = 0; i < elements.size(); i++) {
            int minIndex = i;
            for (int j = i + 1; j < elements.size(); j++) {
                if (elements.get(j).compareTo(elements.get(minIndex)) > 0) {
                    minIndex = j;
                }
                System.out.println(elements); 
            }
    
            String temp = elements.get(i);
            elements.set(i, elements.get(minIndex));
            elements.set(minIndex, temp);
        }
    }

     public static void WordSelectionSort2(ArrayList<String> elements) {
        for (int i = 0; i < elements.size(); i++) {
            int minIndex = i;
            for (int j = i + 1; j < elements.size(); j++) {
                if (elements.get(j).compareTo(elements.get(minIndex)) < 0) {
                    minIndex = j;
                }
                System.out.println(elements); 
            }
    
            String temp = elements.get(i);
            elements.set(i, elements.get(minIndex));
            elements.set(minIndex, temp);
        }
    }

     public static void InsertionSort(ArrayList<Integer> insertionSortArray) {
        for (int i = 1; i < insertionSortArray.size(); i++) {
            int key = insertionSortArray.get(i);
            int j = i - 1;

            while (j >= 0 && insertionSortArray.get(j) > key) {
                insertionSortArray.set(j + 1, insertionSortArray.get(j));
                j--;
            }
            insertionSortArray.set(j + 1, key);
            System.out.println(insertionSortArray);
        }
    }

    public static void InsertionSort2(ArrayList<Integer> insertionSortArray2) {
        for (int i = 1; i < insertionSortArray2.size(); i++) {
            int key = insertionSortArray2.get(i);
            int j = i - 1;

            while (j >= 0 && insertionSortArray2.get(j) < key) {
                insertionSortArray2.set(j + 1, insertionSortArray2.get(j));
                j--;
            }
            insertionSortArray2.set(j + 1, key);
            System.out.println(insertionSortArray2);
        }
    }

    public static void WordInsertionSort(ArrayList<String> elements) {
        for (int i = 1; i < elements.size(); i++) 
        {
            String key = elements.get(i);
            int j = i - 1;
        
            while (j >= 0 && elements.get(j).compareTo(key) < 0) 
            {
                elements.set(j + 1, elements.get(j));
                j--;
            }
                elements.set(j + 1, key);

        
            System.out.println(elements);
        }
    }

    public static void WordInsertionSort2(ArrayList<String> elements) 
    {
        for (int i = 1; i < elements.size(); i++)
         {
            String key = elements.get(i);
            int j = i - 1;

            while (j >= 0 && elements.get(j).compareTo(key) > 0) 
            {
                elements.set(j + 1, elements.get(j));
                j--;
            }
            elements.set(j + 1, key);

            System.out.println(elements);
        }
    }


    public static void main(String str[]) throws IOException {

        Scanner scan = new Scanner(System.in);
        int userInput;
        String userInput1;

        System.out.println("Please enter 6 int values.");
        ArrayList<Integer> InsertionSortArray = new ArrayList<Integer>();
        ArrayList<Integer> SelectionSortArray = new ArrayList<Integer>();
        ArrayList<Integer> InsertionSortArray2 = new ArrayList<Integer>();
        ArrayList<Integer> SelectionSortArray2 = new ArrayList<Integer>();
        for (int i = 0; i < 6; i++) {
            userInput = scan.nextInt();
            InsertionSortArray.add(userInput);
            SelectionSortArray.add(userInput);
            InsertionSortArray2.add(userInput);
            SelectionSortArray2.add(userInput);
            
        }

        System.out.println("\nPrinting unsorted Selection Sort Array: " + SelectionSortArray);
        System.out.println("\nPrinting each pass through the Selection Sort:");
        SelectionSort(SelectionSortArray);
        System.out.println("\nPrinting unsorted Insertion Sort Array: " + InsertionSortArray);
        System.out.println("\nPrinting each pass through the Insertion Sort:");
        InsertionSort(InsertionSortArray);

        System.out.println("Please enter 5 Strings.");
        ArrayList<String> WordInsertionSortArray = new ArrayList<String>();
        ArrayList<String> WordSelectionSortArray = new ArrayList<String>();
        ArrayList<String> WordInsertionSortArray2 = new ArrayList<String>();
        ArrayList<String> WordSelectionSortArray2 = new ArrayList<String>();
        for (int i = 0; i < 6; i++) 
        {
            userInput1 = scan.nextLine();
            WordInsertionSortArray.add(userInput1);
            WordSelectionSortArray.add(userInput1);
            WordInsertionSortArray2.add(userInput1);
            WordSelectionSortArray2.add(userInput1);
        }
    // Words in Alphabetical Order


    System.out.println("\nPrinting unsorted Word Selection Sort Array: " + WordSelectionSortArray2);
    System.out.println("\nPrinting each pass through the Selection Sort:");
    WordSelectionSort2(WordSelectionSortArray2);
    System.out.println("\nPrinting unsorted Word Insertion Sort Array: " + WordInsertionSortArray2);
    System.out.println("\nPrinting each pass through the Insertion Sort:");
    WordInsertionSort2(WordInsertionSortArray2);
   

   // Decreasing Order (Int)

    System.out.println("\nPrinting unsorted Selection Sort Array: " + SelectionSortArray2);
    System.out.println("\nPrinting each pass through the Selection Sort:");
    SelectionSort2(SelectionSortArray2);
    System.out.println("\nPrinting unsorted Insertion Sort Array: " + InsertionSortArray2);
    System.out.println("\nPrinting each pass through the Insertion Sort:");
    InsertionSort2(InsertionSortArray2);

    // Decreasing Order (Strings)

    System.out.println("\nPrinting unsorted Word Selection Sort Array2b: " + WordSelectionSortArray);
    System.out.println("\nPrinting each pass through the Selection Sort:");
    WordSelectionSort(WordSelectionSortArray);
    System.out.println("\nPrinting unsorted Word Insertion Sort Array2b: " + WordInsertionSortArray);
    System.out.println("\nPrinting each pass through the Insertion Sort:");
    WordInsertionSort(WordInsertionSortArray);
    
}
}
