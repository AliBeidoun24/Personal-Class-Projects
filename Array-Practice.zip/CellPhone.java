public class CellPhone
  {
   //instance data
  private String brand; //"brand" - Shows the brand of the CellPhone
    private String model; //"model" - Shows the model of the CellPhone
    private String mobileCarrier; //"mobileCarrier" - Shows the Mobile Carrier of the CellPhone
  private int yor; //"yor" - "Year of Release"
  private double ram; //"ram" - Shows the amount of Random Access Memory in Gb
  private boolean supports5G; //"supports5G" - Shows if CellPhone Supports 5G
  private static int count;


//constructor with Parameters
public CellPhone(String b, String m, String mc,int y, double r, boolean sfg)
  {
  setBrand(b);
  setModel(m);
  setMobileCarrier(mc);
  setYor(y);
  setRam(r);
  setSupports5G(sfg);
  count++;
  }

//constructor Without Parameters - this
public CellPhone()
  {
  this("Unknown", "Unknown", "Unkown", 0, 0.0, false);
  }

//Accessor Methods

public String getBrand()
  {
  return brand;
  }

public String getModel()
  {
  return model;
  }

public String getMobileCarrier()
  {
  return mobileCarrier;
  }
    
public int getYor()
  {
  return yor;
  }

public double getRam()
  {
  return ram;
  }

public boolean getSupports5G()
  {
  return supports5G;
  }

public static int getCount()
  {
  return count;
  }


//mutator methods

public void setBrand(String b)
  {
  brand = b;
  }

public void setModel(String m)
  {
  model = m;
  }

public void setMobileCarrier(String mc)
  {
  mobileCarrier = mc;
  }

public void setYor(int y)
  {
  yor = y;
  }


public void setRam(double r)
  {
  ram = r;
  }

public void setSupports5G(boolean sfg)
  {
  supports5G = sfg;
  }

//OTHER METHOD(S)
//Same Brand Identifier (Other Method 1)
public boolean equals(CellPhone cp_2)
{
 if (brand.equals(cp_2.getBrand()))
 {
 return true;
 }
 return false;
}


//V.2 Same Brand Identifier (Other Method 3)
public int compareTo(CellPhone cP)
  {
    String bs = cP.getBrand();
    String tn = this.brand;
    if(this.equals(cP))
    {
      return 0;
    }
    else if(tn.compareTo(bs)<0)
    {
      return -1;
    }
    else
    {
      return 1;
    }
  }

/*
//5G Support Identifier (Other Method 2)
public boolean equalFG(CellPhone cp_1, CellPhone cp_2)
{
 if (cp_1.getSupports5G() == true && cp_2.getSupports5G() == true)
 {
 return true;
 }
 return false;
}
*/
/*    
//toString method
public String toString()
{
 return "\n Cell Phone brand: " + brand + "\n Model: " + model + "\n Mobile Carrier: "+ mobileCarrier + "\n Year of Release: " + yor + "\n RAM: " + ram + " Gb" + "\n Supports 5G: " + supports5G;
}

}
*/
  public String toString()
  {
    return "Phone brand: " + brand;
  }
}