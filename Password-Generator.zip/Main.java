import java.util.*;
import java.io.*;

class Main {
  public static void main(String[] args) throws IOException {
    // user interface

    Scanner scan = new Scanner(System.in);
    System.out.println(
        "Welcome to the password generator!\n\nPlease select which type of password you would like to generate.\n\n1. Lowercase\n2. Uppercase\n3. Uppercase and Lowercase\n4. Uppercase, Lowercase, Numbers\n5. Uppercase, Lowercase, Numbers, and Symbols\n0. Exit\n\nEnter selection by typing numbers 1, 2, 3, 4, 5, or 0: ");
    int userInput = scan.nextInt();
    while (userInput != 0) {
      if (userInput == 1) {
        // lowercase only
        FileWriter lower = new FileWriter("Lower.txt");
        PrintWriter LNStore = new PrintWriter(lower);
        int[] lowARr = new int[1000];
        char[] lowARR = new char[1000];
        for (int i = 0; i < 1000; i++) {
          int num1 = (int) (Math.random() * 25) + 97;
          lowARr[i] = num1;
          lowARR[i] = (char) lowARr[i];
          LNStore.println(num1);
        }
        LNStore.close();
        FileWriter lowerPW = new FileWriter("Lowerpw.txt");
        PrintWriter LPStore = new PrintWriter(lowerPW);
        int passIn = 0;
        int lowARRIn = 0;
        while (lowARRIn < 1000) {
          if (passIn == 8) {
            passIn = 0;
            LPStore.println();
          }
          LPStore.print(lowARR[lowARRIn]);
          passIn++;
          lowARRIn++;
        }
        LPStore.close();
        System.out.println(
            "Check the Lowerpw.txt file for the passwords!\n\nPlease select which type of password you would like to generate.\n\n1. Lowercase\n2. Uppercase\n3. Uppercase and Lowercase\n4. Uppercase, Lowercase, Numbers\n5. Uppercase, Lowercase, Numbers, and Symbols\n0. Exit\n\nEnter selection by typing numbers 1, 2, 3, 4, 5, or 0: ");
        userInput = scan.nextInt();
      } else if (userInput == 2) {
        // uppercase only
        FileWriter upper = new FileWriter("Upper.txt");
        PrintWriter UNStore = new PrintWriter(upper);
        int[] uppARr = new int[1000];
        char[] uppARR = new char[1000];
        for (int i = 0; i < 1000; i++) {
          int num1 = (int) (Math.random() * 25) + 65;
          uppARr[i] = num1;
          uppARR[i] = (char) uppARr[i];
          UNStore.println(num1);
        }
        
        FileWriter upperPW = new FileWriter("Upperpw.txt");
        PrintWriter UPStore = new PrintWriter(upperPW);
        int passIndex2 = 0;
        int uppARRIndex = 0;
        while (uppARRIndex < 1000) {
          if (passIndex2 == 8) {
            passIndex2 = 0;
            UPStore.println();
          }
          UPStore.print(uppARR[uppARRIndex]);
          passIndex2++;
          uppARRIndex++;
        }
        UPStore.close();
        System.out.println(
            "Check the Upperpw.txt file for the passwords!\n\nPlease select which type of password you would like to generate.\n\n1. Lowercase\n2. Uppercase\n3. Uppercase and Lowercase\n4. Uppercase, Lowercase, Numbers\n5. Uppercase, Lowercase, Numbers, and Symbols\n0. Exit\n\nEnter selection by typing numbers 1, 2, 3, 4, 5, or 0: ");
        userInput = scan.nextInt();
      } else if (userInput == 3) {
        // uppercase and lowercase
        FileWriter mixedLetters = new FileWriter("Mixed_letters.txt");
        PrintWriter MLStore = new PrintWriter(mixedLetters);
        int[] mixedLettARr = new int[1000];
        char[] mixedLettARR = new char[1000];
        for (int i = 0; i < 1000; i++) {
          int num33 = (int) (Math.random() * 2) + 1;
          if (num33 == 1) {
            int num3 = (int) (Math.random() * 25) + 97;
            mixedLettARr[i] = num3;
            mixedLettARR[i] = (char) mixedLettARr[i];
            MLStore.println(num3);
          } else {
            int num3 = (int) (Math.random() * 25) + 65;
            mixedLettARr[i] = num3;
            mixedLettARR[i] = (char) mixedLettARr[i];
            MLStore.println(num3);
          }
        }
        MLStore.close();
        FileWriter mixedLettPW = new FileWriter("Mixedpw.txt");
        PrintWriter MLPStore = new PrintWriter(mixedLettPW);
        int passIndex3 = 0;
        int mixedLettARRIndex = 0;
        while (mixedLettARRIndex < 1000) {
          if (passIndex3 == 8) {
            passIndex3 = 0;
            MLPStore.println();
          }
          MLPStore.print(mixedLettARR[mixedLettARRIndex]);
          passIndex3++;
          mixedLettARRIndex++;
        }
        MLPStore.close();
        System.out.println(
            "Check the Mixedpw.txt file for the passwords!\n\nPlease select which type of password you would like to generate.\n\n1. Lowercase\n2. Uppercase\n3. Uppercase and Lowercase\n4. Uppercase, Lowercase, Numbers\n5. Uppercase, Lowercase, Numbers, and Symbols\n0. Exit\n\nEnter selection by typing numbers 1, 2, 3, 4, 5, or 0: ");
        userInput = scan.nextInt();
      } else if (userInput == 4) {
        // uppercase/lowercase/numbers
        FileWriter mixedLetterNum = new FileWriter("Mixed_letters_numbers.txt");
        PrintWriter mixedLetterNumStore = new PrintWriter(mixedLetterNum);
        int[] mixedLettNumARr = new int[1000];
        char[] mixedLettNumARR = new char[1000];
        for (int i = 0; i < 1000; i++) {
          int num44 = (int) (Math.random() * 3) + 1;
          if (num44 == 1) {
            int num4 = (int) (Math.random() * 25) + 97;
            mixedLettNumARr[i] = num4;
            mixedLettNumARR[i] = (char) mixedLettNumARr[i];
            mixedLetterNumStore.println(num4);
          } else if (num44 == 2) {
            int num4 = (int) (Math.random() * 25) + 65;
            mixedLettNumARr[i] = num4;
            mixedLettNumARR[i] = (char) mixedLettNumARr[i];
            mixedLetterNumStore.println(num4);
          } else {
            int num4 = (int) (Math.random() * 9) + 48;
            mixedLettNumARr[i] = num4;
            mixedLettNumARR[i] = (char) mixedLettNumARr[i];
            mixedLetterNumStore.println(num4);
          }
        }
        mixedLetterNumStore.close();
        FileWriter mixedLettNumPW = new FileWriter("MixedNumpw.txt");
        PrintWriter mixedLettNumPassStore = new PrintWriter(mixedLettNumPW);
        int passIndex4 = 0;
        int mixedLettNumARRIndex = 0;
        while (mixedLettNumARRIndex < 1000) {
          if (passIndex4 == 8) {
            passIndex4 = 0;
            mixedLettNumPassStore.println();
          }
          mixedLettNumPassStore.print(mixedLettNumARR[mixedLettNumARRIndex]);
          passIndex4++;
          mixedLettNumARRIndex++;
        }
        mixedLettNumPassStore.close();
        System.out.println(
            "Check the MixedNumpw.txt file for the passwords!\n\nPlease select which type of password you would like to generate.\n\n1. Lowercase\n2. Uppercase\n3. Uppercase and Lowercase\n4. Uppercase, Lowercase, Numbers\n5. Uppercase, Lowercase, Numbers, and Symbols\n0. Exit\n\nEnter selection by typing numbers 1, 2, 3, 4, 5, or 0: ");
        userInput = scan.nextInt();
      } else if (userInput == 5) {
        FileWriter allChars = new FileWriter("Mixed_chars.txt");
        PrintWriter allCharsStore = new PrintWriter(allChars);
        int[] allChARrs = new int[1000];
        char[] allChARRs = new char[1000];
        for (int i = 0; i < 1000; i++) {
          int num1 = (int) (Math.random() * 94) + 33;
          allChARrs[i] = num1;
          allChARRs[i] = (char) allChARrs[i];
          allCharsStore.println(num1);
        }
        allCharsStore.close();
        FileWriter allCharsPW = new FileWriter("AllCharspw.txt");
        PrintWriter allCharsPassStore = new PrintWriter(allCharsPW);
        int allCharsPassIndex = 0;
        int allChARRsIndex = 0;
        while (allChARRsIndex < 1000) {
          if (allCharsPassIndex == 8) {
            allCharsPassIndex = 0;
            allCharsPassStore.println();
          }
          allCharsPassStore.print(allChARRs[allChARRsIndex]);
          allCharsPassIndex++;
          allChARRsIndex++;
        }
        allCharsPassStore.close();
        System.out.println(
            "Check the AllCharspw.txt file for the passwords!\n\nPlease select which type of password you would like to generate.\n\n1. Lowercase\n2. Uppercase\n3. Uppercase and Lowercase\n4. Uppercase, Lowercase, Numbers\n5. Uppercase, Lowercase, Numbers, and Symbols\n0. Exit\n\nEnter selection by typing numbers 1, 2, 3, 4, 5, or 0: ");
        userInput = scan.nextInt();
      } else {
        System.out.println(
            "Enter a valid value listed above.\n\nPlease select which type of password you would like to generate.\n\n1. Lowercase\n2. Uppercase\n3. Uppercase and Lowercase\n4. Uppercase, Lowercase, Numbers\n5. Uppercase, Lowercase, Numbers, and Symbols\n0. Exit\n\nEnter selection by typing numbers 1, 2, 3, 4, 5, or 0: ");
        userInput = scan.nextInt();
      }
    }
  }
}