

import java.lang.Math;
import java.util.ArrayList;

class Main {

    public static double productCost(Product prod) {
        return (prod.getPrice()) * (prod.getQuantity());
    }

    public static double grandTotal(ArrayList<Product> list) {
        double total = 0;
        for (Product x : list) {
            total += productCost(x);
        }
        return total;
    }

    public static void main(String[] args) {
        ArrayList<Product> cart = new ArrayList<Product>();
        Product Prod = new Product(2.0,"fabric", (int) ((Math.random() * 4) + 3));
        cart.add(Prod);

        Electronics mouse = new Electronics(100, "Aerox 5", (int) ((Math.random() * 4) + 3) , false, true);
        cart.add(mouse);

        Media Insterstellar = new Media(10.0, "Interstellar", (int) ((Math.random() * 4) + 3), "movie");
        cart.add(Insterstellar);

        Clothing Shirt = new Clothing(20.0, "shirt", (int) ((Math.random() * 4) + 3), "large");
        cart.add(Shirt);

        Women Skirt = new Women(30.0, "dress", (int) ((Math.random() * 4) + 3), "medium", false);
        cart.add(Skirt);

        Men Suit = new Men(50, "suit", (int) ((Math.random() * 4) + 3), "large", true);
        cart.add(Suit);

        Product laptop = new Electronics(1500.0, "laptop", (int) ((Math.random() * 4) + 3), true, false);
        cart.add(laptop);

        Product HL = new Media(60.0, "Hogwarts Legacy", (int) ((Math.random() * 4) + 3), "game");
        cart.add(HL);

        Product hat = new Clothing(15.0, "hat", (int) ((Math.random() * 4) + 3), "small");
        cart.add(hat);

        Product dress = new Women(300, "dress", (int) ((Math.random() * 4) + 3), "medium", true);
        cart.add(dress);

        Product shorts = new Men(25.0, "shorts", (int) ((Math.random() * 4) + 3), "large", false);
        cart.add(shorts);


        for(Product x:cart)
        {
        System.out.println(x);
        System.out.println(" ");
        }
  
      System.out.println("\n Name \t Quantity \t Price \t Total Cost");
  
      for(Product x:cart)
        {
          System.out.println("\n" + x.getName()+ "\t" + x.getQuantity()+ "\t $" + x.getPrice() + "\t\t $" + productCost(x));
  
      
  
    }
    System.out.println("Grand Total $"+ grandTotal(cart));
    }
}

