class Media extends Product {

    private String type;

    Media(double p, String n, int q, String t) {
        super(p, n, q);
        setType(t);
    }

    public double getPrice() {
        return super.getPrice();
    }

    public String getName() {
        return super.getName();
    }
    
    public int getQuantity() {
        return super.getQuantity();
    }

    public void setPrice(double p) {
        super.setPrice(p);

    }

    public void setQuantity(int q) {
        super.setQuantity(q);
    } 

    public void setName(String n) {
        super.setName(n);
    }

    public String getType() {
        return type;
    }

    public void setType(String t) {
        type = t;
    }

    @Override
    public String toString() {
        return super.toString() + " the type is a " + type;
    }

} 
