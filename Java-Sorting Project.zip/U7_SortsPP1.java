import java.io.*;
import static java.lang.System.*;
import java.util.Scanner;
import java.lang.Math;
import java.util.ArrayList;
import java.util.Arrays;

public class U7_SortsPP1 {
    // Selection Sorting

    public static void SelectionSort(int[] elements) {
        for (int i = 0; i < elements.length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < elements.length; j++) {
                if (elements[j] < elements[minIndex]) {
                    minIndex = j;
                }
            }
            
            System.out.println(Arrays.toString(elements));
            
            int temp = elements[i];
            elements[i] = elements[minIndex];
            elements[minIndex] = temp;
        }
    }

    public static void SelectionSort2(int[] elements) {
        for (int i = 0; i < elements.length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < elements.length; j++) {
                if (elements[j] > elements[minIndex]) {
                    minIndex = j;
                }
            }
            
            System.out.println(Arrays.toString(elements));
            
            int temp = elements[i];
            elements[i] = elements[minIndex];
            elements[minIndex] = temp;
        }
    }

    public static void WordSelectionSort(String[] elements) {
        for (int i = 0; i < elements.length; i++) {
            int minIndex = i;
            for (int j = i + 1; j < elements.length; j++) {
                if (elements[j].compareTo(elements[minIndex]) > 0) {
                    minIndex = j;
                }
                System.out.println(java.util.Arrays.toString(elements)); 
            }
    
            String temp = elements[i];
            elements[i] = elements[minIndex];
            elements[minIndex] = temp;
        }
    }


    public static void WordSelectionSort2(String[] elements) {
        for (int i = 0; i < elements.length; i++) {
            int minIndex = i;
            for (int j = i + 1; j < elements.length; j++) {
                if (elements[j].compareTo(elements[minIndex]) < 0) {
                    minIndex = j;
                }
                System.out.println(java.util.Arrays.toString(elements)); 
            }
    
            String temp = elements[i];
            elements[i] = elements[minIndex];
            elements[minIndex] = temp;
        }
    }

    // Insertion Sorting

    public static void InsertionSort(int[] elements) {
        for (int i = 1; i < elements.length; i++) {
            int key = elements[i];
            int j = i - 1;

            while (j >= 0 && elements[j] > key) {
                elements[j + 1] = elements[j];
                j--;
            }
            elements[j + 1] = key;

            
            for (int k = 0; k < elements.length; k++) {
                System.out.print(elements[k] + " ");
            }
            System.out.println();
        }
    }

    public static void InsertionSort2(int[] elements) {
        for (int i = 1; i < elements.length; i++) {
            int key = elements[i];
            int j = i - 1;

            while (j >= 0 && elements[j] < key) {
                elements[j + 1] = elements[j];
                j--;
            }
            elements[j + 1] = key;

            
            for (int k = 0; k < elements.length; k++) {
                System.out.print(elements[k] + " ");
            }
            System.out.println();
        }
    }

    public static void WordInsertionSort(String[] elements) {
        for (int i = 1; i < elements.length; i++) 
        {
            String key = elements[i];
            int j = i - 1;
        
            while (j >= 0 && elements[j].compareTo(key) < 0) 
            {
                elements[j + 1] = elements[j];
                j--;
            }
                elements[j + 1] = key;

        
            for (int k = 0; k < elements.length; k++) 
            {
                System.out.print(elements[k] + " ");
            }
            System.out.println();
        }
    }

    public static void WordInsertionSort2(String[] elements) 
    {
        for (int i = 1; i < elements.length; i++)
         {
            String key = elements[i];
            int j = i - 1;

            while (j >= 0 && elements[j].compareTo(key) > 0) 
            {
                elements[j + 1] = elements[j];
                j--;
            }
            elements[j + 1] = key;

            
            for (int k = 0; k < elements.length; k++) 
            {
                System.out.print(elements[k] + " ");
            }
            System.out.println();
        }
    }
    

    // Main Class
    public static void main(String str[]) throws IOException {

        Scanner scan = new Scanner(System.in);
        int userInput;
        String userInput1;

        System.out.println("Please enter 6 int values.");
        int[] InsertionSortArray = new int[6];
        int[] SelectionSortArray = new int[6];
        int[] InsertionSortArray2 = new int[6];
        int[] SelectionSortArray2 = new int[6];
        for (int i = 0; i < 6; i++) {
            userInput = scan.nextInt();
            InsertionSortArray[i] = userInput;
            SelectionSortArray[i] = userInput;
            InsertionSortArray2[i] = userInput;
            SelectionSortArray2[i] = userInput;
        }

        System.out.println("\nPrinting unsorted Selection Sort Array: " + Arrays.toString(SelectionSortArray));
        System.out.println("\nPrinting each pass through the Selection Sort:");
        SelectionSort(SelectionSortArray);
        System.out.println("\nPrinting unsorted Insertion Sort Array: " + Arrays.toString(InsertionSortArray));
        System.out.println("\nPrinting each pass through the Insertion Sort:");
        InsertionSort(InsertionSortArray);

        System.out.println("Please enter 5 Strings.");
            String[] WordInsertionSortArray = new String[6];
            String[] WordSelectionSortArray = new String[6];
            String[] WordInsertionSortArray2 = new String[6];
            String[] WordSelectionSortArray2 = new String[6];
        for (int i = 0; i < 6; i++) 
        {
            userInput1 = scan.nextLine();
            WordInsertionSortArray[i] = userInput1;
            WordSelectionSortArray[i] = userInput1;
            WordInsertionSortArray2[i] = userInput1;
            WordSelectionSortArray2[i] = userInput1;
        }

        // Words in Alphabetical Order


        System.out.println("\nPrinting unsorted Word Selection Sort Array: " + Arrays.toString(WordSelectionSortArray2));
        System.out.println("\nPrinting each pass through the Selection Sort:");
        WordSelectionSort2(WordSelectionSortArray2);
        System.out.println("\nPrinting unsorted Word Insertion Sort Array: " + Arrays.toString(WordInsertionSortArray2));
        System.out.println("\nPrinting each pass through the Insertion Sort:");
        WordInsertionSort2(WordInsertionSortArray2);
       

       // Decreasing Order (Int)

        System.out.println("\nPrinting unsorted Selection Sort Array: " + Arrays.toString(SelectionSortArray2));
        System.out.println("\nPrinting each pass through the Selection Sort:");
        SelectionSort2(SelectionSortArray2);
        System.out.println("\nPrinting unsorted Insertion Sort Array: " + Arrays.toString(InsertionSortArray2));
        System.out.println("\nPrinting each pass through the Insertion Sort:");
        InsertionSort2(InsertionSortArray2);

        // Decreasing Order (Strings)

        System.out.println("\nPrinting unsorted Word Selection Sort Array2b: " + Arrays.toString(WordSelectionSortArray));
        System.out.println("\nPrinting each pass through the Selection Sort:");
        WordSelectionSort(WordSelectionSortArray);
        System.out.println("\nPrinting unsorted Word Insertion Sort Array2b: " + Arrays.toString(WordInsertionSortArray));
        System.out.println("\nPrinting each pass through the Insertion Sort:");
        WordInsertionSort(WordInsertionSortArray);
        
    }

}