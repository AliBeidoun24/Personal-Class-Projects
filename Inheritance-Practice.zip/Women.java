class Women extends Clothing {

    private Boolean isDress;

    Women(double p, String n, int q, String s, Boolean Dress) {
        super(p, n, q, s);
        setDress(Dress);
    }

    public double getPrice() {
        return super.getPrice();
    }
    
    public int getQuantity() {
        return super.getQuantity();
    }

    public void setPrice(double p) {
        super.setPrice(p);

    }

    public void setQuantity(int q) {
        super.setQuantity(q);
    } 

    public boolean getDress () {
       return getDress();
    }

    public String getName() { 
        return super.getName();
    }

    public void setDress (boolean Dress) {
        isDress = Dress;
    }

    public void setName(String n) { 
        super.setName(n);
    }

    @Override
    public String toString() {
        return super.toString() + " is dress " + isDress;
    }

} 