class Clothing extends Product {

    protected String size;

    Clothing(double p, String n, int q, String s) {
        super(p, n, q);
        setSize(s);
    }

    public double getPrice() {
        return super.getPrice();
    }
    
    public int getQuantity() {
        return super.getQuantity();
    }

    public void setPrice(double p) {
        super.setPrice(p);

    }

    public void setQuantity(int q) {
        super.setQuantity(q);
    } 

    public void setName(String n) {
        super.setName(n);
    }

    public String getName() {
        return super.getName();
    } 
     
    public String getSize() {
        return size;
    } 

    public void setSize(String s) { 
        size = s;
    }

    @Override
    public String toString() {
        return super.toString() + " the size is " + size;
    }


}