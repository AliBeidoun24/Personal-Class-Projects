class Men extends Clothing {

    private boolean isSuit;

    Men(double p, String n, int q, String s, Boolean Suit) {
        super(p, n, q, s);
        setSuit(Suit);
    }

    public boolean getSuit () {
        return getSuit();
    }

    public String getName() { 
        return super.getName();
    }

    public void setSuit (boolean Suits) {
        isSuit = Suits;
    }

    public void setName(String n) { 
        super.setName(n);
    }

    public double getPrice() {
        return super.getPrice();
    }
    
    public int getQuantity() {
        return super.getQuantity();
    }

    public void setPrice(double p) {
        super.setPrice(p);

    }

    public void setQuantity(int q) {
        super.setQuantity(q);
    } 


    @Override
    public String toString() {
        return super.toString() + " is this a suit " + isSuit ; 
    }

}