public class Product //Parent Class
{
  //instance Data
  private double price;
  private String name;
  private int quantity;


  //Constructor with Parameters
public Product(double p, String n, int q)
{
setName(n);
setQuantity(q);
setPrice(p);
}


  // Mutator Method
  public void setName(String s)
{
name = s;
}
  public void setQuantity(int x)
{
quantity = x;
}
  public void setPrice(double d)
{
price = d;
}

// Accessor Method
public String getName()
{
return name;
}

  public double getPrice()
{
return price;
}
  
  public int getQuantity()
{
return quantity;
}

//toString-always last method in a Class
    public String toString()
    {
      return "The item is " + name + " there is a total of " + quantity + " the price is $" + price;
    }
}