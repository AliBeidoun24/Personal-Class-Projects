class Electronics extends Product {

    private boolean batteryIncluded;
    private boolean wireless; 

    Electronics(double p, String n, int q, Boolean bI, boolean w) {
        super(p, n, q);
        setBattInc(bI);
        setWireless(w);
    }

    public double getPrice() {
        return super.getPrice();
    }

    public String getName() {
        return super.getName();
    }
    
    public int getQuantity() {
        return super.getQuantity();
    }

    public void setPrice(double p) {
        super.setPrice(p);

    }

    public void setQuantity(int q) {
        super.setQuantity(q);
    } 

    public void setName(String n) {
        super.setName(n);
    }

    private boolean getBattInc() {
        return batteryIncluded;
    }

    private boolean getWireless() {
        return wireless;
    }

    private void setBattInc(boolean bI) {
        batteryIncluded = bI;
    }

    private void setWireless(boolean w) {
        wireless = w;
    }

    @Override
    public String toString() {
        
        return super.toString() + " batteries are inlcuded " + batteryIncluded + " is wireless " + wireless;
    }

}